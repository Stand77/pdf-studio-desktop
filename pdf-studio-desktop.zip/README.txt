PDF Studio desktop
1. Run in PowerShell from this folder:  .\build.ps1     (downloads libs once, creates app.asar)
2. Copy app.asar into <your electron runtime>\resources\  (replace the default app), or test with:  npx --yes electron .\app
Notes: Save opens a native Save As dialog. OCR (Claude-powered) is not available offline; Word/Excel export of text PDFs works.

New: Select text tool (drag a box over text to copy it) and Paste text (button or Ctrl+V, then click the page to place it).

To make a single portable exe:  powershell -ExecutionPolicy Bypass -File .\build-exe.ps1   (result: dist\PDF-Studio.exe)
